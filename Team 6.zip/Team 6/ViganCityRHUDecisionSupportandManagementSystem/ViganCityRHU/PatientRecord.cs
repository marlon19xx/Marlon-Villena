﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ViganCityRHU
{
    public partial class PatientRecord : Form
    {
        dbconn con = new dbconn();
        public PatientRecord()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string code = txtcode.Text.ToString();

            string sqlSelect1 = "SELECT `Patient_ID`, `Initial_Diagnosis`, `Doctors_final_diagnosis` `FROM `Patient_record` WHERE `Patient_ID` = '" + code + "'";
            con.selectproductcode2(sqlSelect1, lblcode1,lvi_recs);

            string sqlSelect2 = "SELECT `Firstname`, `Middlename`, `Lastname`, `Ext`, `Age`, `Brgy`, `City`, `Province`, Zip` FROM `Patient_info_medical` WHERE `Patient_ID` = '" + code + "'";
            con.selectprodutcode2(sqlSelect2, lblcode1, lvi_recs);


            if (code == lblcode1.Text)
            {

                string sqlSelect3 = "SELECT * FROM `Patient_record` WHERE `Patient_ID` = '" + code + "'";
                con.selectallrecords(sqlSelect3, lvi_recs);

            }

            else
            {
                MessageBox.Show("ID Not Found");
            }
        }

        private void PatientRecord_Load(object sender, EventArgs e)
        {
            string sqlSelect2 = "SELECT * FROM `patient_info_medical` LEFT JOIN `patient_record` ON `patien_info_medical`.`Patient_ID` = `patient_record`.`Patient_ID`";
            con.selectRecs(sqlSelect2, lvi_recs);
        }

        private void picback_Click(object sender, EventArgs e)
        {
            DoctorsMainForm a = new DoctorsMainForm();
            a.Show();
            this.Hide();
        }
    }
}

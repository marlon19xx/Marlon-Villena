﻿namespace ViganCityRHU
{
    partial class DoctorsMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMedicalCheckup = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnDentalcheckup = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMedicalCheckup
            // 
            this.btnMedicalCheckup.Location = new System.Drawing.Point(145, 132);
            this.btnMedicalCheckup.Name = "btnMedicalCheckup";
            this.btnMedicalCheckup.Size = new System.Drawing.Size(132, 68);
            this.btnMedicalCheckup.TabIndex = 0;
            this.btnMedicalCheckup.Text = "MEDICAL CHECK UP";
            this.btnMedicalCheckup.UseVisualStyleBackColor = true;
            this.btnMedicalCheckup.Click += new System.EventHandler(this.btnMedicalCheckup_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(308, 132);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(132, 68);
            this.button2.TabIndex = 1;
            this.button2.Text = "PATIENT\'S RECORD";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnDentalcheckup
            // 
            this.btnDentalcheckup.Location = new System.Drawing.Point(145, 218);
            this.btnDentalcheckup.Name = "btnDentalcheckup";
            this.btnDentalcheckup.Size = new System.Drawing.Size(132, 68);
            this.btnDentalcheckup.TabIndex = 0;
            this.btnDentalcheckup.Text = "DENTAL CHECK UP";
            this.btnDentalcheckup.UseVisualStyleBackColor = true;
            this.btnDentalcheckup.Click += new System.EventHandler(this.btnDentalcheckup_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(308, 218);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(132, 68);
            this.btnLogout.TabIndex = 0;
            this.btnLogout.Text = "LOGOUT";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // DoctorsMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.ClientSize = new System.Drawing.Size(584, 418);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnDentalcheckup);
            this.Controls.Add(this.btnMedicalCheckup);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DoctorsMainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DoctorsMainForm(MEDICAL)";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMedicalCheckup;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnDentalcheckup;
        private System.Windows.Forms.Button btnLogout;
    }
}
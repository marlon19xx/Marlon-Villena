﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ViganCityRHU
{
    public partial class Form1 : Form
    {
        dbconn con = new dbconn();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Label lbluser = new Label();
            Label lblpass = new Label();
            Label lbluser1 = new Label();
            Label lblpass1 = new Label();
            Label lbluser2 = new Label();
            Label lblpass2 = new Label();
            string pass = con.encryption(txtpass.Text.Trim().ToString());
            string user = txtuser.Text.Trim().ToString();
            string user1 = lbluser.Text.Trim().ToString();
            string pass1 = lblpass.Text.Trim().ToString();

            string sqlSelect = "SELECT `Username`, `Password` FROM `Doctor` WHERE `Username` = '" + user + "'";
            con.selectwho(sqlSelect, lbluser, lblpass);

            string sqlSelect1 = "SELECT `Username`, `Password` FROM `Pharmacist` WHERE `Username` = '" + user + "'";
            con.selectwho1(sqlSelect1, lbluser1, lblpass1);

            string sqlSelect2 = "SELECT `Username`, `Password` FROM `Nurse` WHERE `Username` = '" + user + "'";
            con.selectwho2(sqlSelect2, lbluser2, lblpass2);

            if (user == lbluser.Text && pass == lblpass.Text)
            {

                MessageBox.Show("Logged In Successfully!");

                DoctorsMainForm a = new DoctorsMainForm();
                a.Show();
                this.Hide();


            }
            else if (user == lbluser1.Text && pass == lblpass1.Text)
            {
                Transaction a = new Transaction();
                a.Show();
                this.Hide();
            }
            else if (user == lbluser2.Text && pass == lblpass2.Text)
            {
                Nurse a = new Nurse();
                a.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong Information");
            }



        }

        private void picback_Click(object sender, EventArgs e)
        {
            ViganCityRHUMainForm a = new ViganCityRHUMainForm();
            a.Show();
            this.Hide();
        }
    }
}

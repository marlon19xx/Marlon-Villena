﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ViganCityRHU
{
    public partial class RegistrationHome : Form
    {
        public RegistrationHome()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            MEDPatientRegistration a = new MEDPatientRegistration();
            a.Show();
            this.Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            DENPatientRegistration a = new DENPatientRegistration();
            a.Show();
            this.Hide();
        }

        private void picback_Click(object sender, EventArgs e)
        {
            ViganCityRHUMainForm a = new ViganCityRHUMainForm();
            a.Show();
            this.Hide();
        }
    }
}

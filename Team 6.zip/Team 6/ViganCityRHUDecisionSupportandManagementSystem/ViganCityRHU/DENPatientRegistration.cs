﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ViganCityRHU
{
    public partial class DENPatientRegistration : Form
    {
        dbconn con = new dbconn();
        public DENPatientRegistration()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fname = txtfname.Text.Trim().ToString();
            string mname = txtmname.Text.Trim().ToString();
            string lname = txtlname.Text.Trim().ToString();
            string ename = txtext.Text.Trim().ToString();
            string brgy = txtbrgy.Text.Trim().ToString();
            string city = txtcity.Text.Trim().ToString();
            string prov = txtprovince.Text.Trim().ToString();
            string zip = mkdzip.Text.Trim().ToString();
            string contact = mkdcontact.Text.Trim().ToString();
            string age = txtage.Text.Trim().ToString();
            string dateofbirth = mkddate.Text.Trim().ToString();
            string civilstatus = cbxstatus.Text.Trim().ToString();
            string citizenship = txtcitizenship.Text.Trim().ToString();
            string sex;


            if (radmale.Checked == true) sex = "Male";
            else if (radmale.Checked == true) sex = "Female";
            else sex = "";



            if (fname == "" || lname == "" || brgy == "" || city == "" || prov == "" || zip == "" || contact == "(+63)    -   -" || sex == "" || dateofbirth == "  /  /" || age == "" || civilstatus == "" || citizenship == "")
            {
                MessageBox.Show("Insufficient Information!");
            }


            else
            {

                string sqlSelectID = "SELECT `Patient_ID` FROM `patient_info_dental` ORDER BY `Patient_ID` DESC";
                Label lbllastid = new Label();
                con.selectID(sqlSelectID, lbllastid);

                int y, x = Convert.ToInt32(lbllastid.Text.Trim().ToString());
                y = x + 1;

                string sqlInsert = "INSERT INTO `Patient_info_dental` (`Patient_ID`,`Firstname`, `Middlename`, `Lastname`, `Ext`, `Age`, `Sex`, `Brgy`, `City`, `Province`, `Zip`,  `Contact`, `Date_of_birth`,`Status`, `Citizenship`) VALUES ('" + y + "','" + fname + "', '" + mname + "', '" + lname + "', '" + ename + "', '" + age + "', '" + sex + "', '" + brgy + "', '" + city + "', '" + prov + "', '" + zip + "', '" + contact + "', '" + dateofbirth + "', '" + civilstatus + "', '" + citizenship + "')";

                con.save(sqlInsert);


                MessageBox.Show("Successfully Registered!");
            }
        }

        private void picback_Click(object sender, EventArgs e)
        {
            RegistrationHome a = new RegistrationHome();
            a.Show();
            this.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ViganCityRHU
{
    public partial class DoctorsMainForm : Form
    {
        public DoctorsMainForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PatientRecord a = new PatientRecord();
            a.Show();
            this.Hide();
        }

        private void picback_Click(object sender, EventArgs e)
        {
            DoctorsMainForm a = new DoctorsMainForm();
            a.Show();
            this.Hide();
        }

        private void btnDentalcheckup_Click(object sender, EventArgs e)
        {
            DoctorsMainForm_DENTAL_ a = new DoctorsMainForm_DENTAL_();
            a.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            ViganCityRHUMainForm a = new ViganCityRHUMainForm();
            a.Show();
            this.Hide();
        }

        private void btnMedicalCheckup_Click(object sender, EventArgs e)
        {
            Patient a = new Patient();
            a.Show();
            this.Hide();
        }

    }
}

﻿namespace ViganCityRHU
{
    partial class Patient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Patient));
            this.lvw = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.txtdiagnosis1 = new System.Windows.Forms.TextBox();
            this.cbxsoarthroat = new System.Windows.Forms.CheckBox();
            this.cbxshivering = new System.Windows.Forms.CheckBox();
            this.cbxfever = new System.Windows.Forms.CheckBox();
            this.cbxdiarrhea = new System.Windows.Forms.CheckBox();
            this.cbxsoreeyes = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.txtpieces = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.lblasdasdas = new System.Windows.Forms.Label();
            this.txtday = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtmg = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtmed = new System.Windows.Forms.TextBox();
            this.cbxstomachache = new System.Windows.Forms.CheckBox();
            this.cbxvomiting = new System.Windows.Forms.CheckBox();
            this.cbxallergies = new System.Windows.Forms.CheckBox();
            this.cbxcough = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.cbxheadache = new System.Windows.Forms.CheckBox();
            this.txtfinal = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button2 = new System.Windows.Forms.Button();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lvw1 = new System.Windows.Forms.ListView();
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.picback = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picback)).BeginInit();
            this.SuspendLayout();
            // 
            // lvw
            // 
            this.lvw.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9});
            this.lvw.Location = new System.Drawing.Point(6, 62);
            this.lvw.Name = "lvw";
            this.lvw.Size = new System.Drawing.Size(602, 409);
            this.lvw.TabIndex = 0;
            this.lvw.UseCompatibleStateImageBehavior = false;
            this.lvw.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID No.";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Fullname";
            this.columnHeader2.Width = 121;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Age";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Sex";
            this.columnHeader4.Width = 102;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Address";
            this.columnHeader5.Width = 64;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Contact";
            this.columnHeader6.Width = 72;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Date Of Birth";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Civil Status";
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Citizenship";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.txtdiagnosis1);
            this.panel1.Controls.Add(this.cbxsoarthroat);
            this.panel1.Controls.Add(this.cbxshivering);
            this.panel1.Controls.Add(this.cbxfever);
            this.panel1.Controls.Add(this.cbxdiarrhea);
            this.panel1.Controls.Add(this.cbxsoreeyes);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.cbxstomachache);
            this.panel1.Controls.Add(this.cbxvomiting);
            this.panel1.Controls.Add(this.cbxallergies);
            this.panel1.Controls.Add(this.cbxcough);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.cbxheadache);
            this.panel1.Controls.Add(this.txtfinal);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(677, 83);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(586, 570);
            this.panel1.TabIndex = 6;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(308, 193);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(46, 30);
            this.button4.TabIndex = 25;
            this.button4.Text = "OK";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // txtdiagnosis1
            // 
            this.txtdiagnosis1.Location = new System.Drawing.Point(23, 159);
            this.txtdiagnosis1.Multiline = true;
            this.txtdiagnosis1.Name = "txtdiagnosis1";
            this.txtdiagnosis1.Size = new System.Drawing.Size(274, 64);
            this.txtdiagnosis1.TabIndex = 24;
            // 
            // cbxsoarthroat
            // 
            this.cbxsoarthroat.AutoSize = true;
            this.cbxsoarthroat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxsoarthroat.Location = new System.Drawing.Point(318, 53);
            this.cbxsoarthroat.Name = "cbxsoarthroat";
            this.cbxsoarthroat.Size = new System.Drawing.Size(86, 19);
            this.cbxsoarthroat.TabIndex = 23;
            this.cbxsoarthroat.Text = "Sore throat";
            this.cbxsoarthroat.UseVisualStyleBackColor = true;
            // 
            // cbxshivering
            // 
            this.cbxshivering.AutoSize = true;
            this.cbxshivering.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxshivering.Location = new System.Drawing.Point(207, 99);
            this.cbxshivering.Name = "cbxshivering";
            this.cbxshivering.Size = new System.Drawing.Size(77, 19);
            this.cbxshivering.TabIndex = 22;
            this.cbxshivering.Text = "Shivering";
            this.cbxshivering.UseVisualStyleBackColor = true;
            // 
            // cbxfever
            // 
            this.cbxfever.AutoSize = true;
            this.cbxfever.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxfever.Location = new System.Drawing.Point(120, 99);
            this.cbxfever.Name = "cbxfever";
            this.cbxfever.Size = new System.Drawing.Size(56, 19);
            this.cbxfever.TabIndex = 21;
            this.cbxfever.Text = "Fever";
            this.cbxfever.UseVisualStyleBackColor = true;
            // 
            // cbxdiarrhea
            // 
            this.cbxdiarrhea.AutoSize = true;
            this.cbxdiarrhea.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxdiarrhea.Location = new System.Drawing.Point(120, 76);
            this.cbxdiarrhea.Name = "cbxdiarrhea";
            this.cbxdiarrhea.Size = new System.Drawing.Size(74, 19);
            this.cbxdiarrhea.TabIndex = 20;
            this.cbxdiarrhea.Text = "Diarrhea";
            this.cbxdiarrhea.UseVisualStyleBackColor = true;
            // 
            // cbxsoreeyes
            // 
            this.cbxsoreeyes.AutoSize = true;
            this.cbxsoreeyes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxsoreeyes.Location = new System.Drawing.Point(120, 53);
            this.cbxsoreeyes.Name = "cbxsoreeyes";
            this.cbxsoreeyes.Size = new System.Drawing.Size(81, 19);
            this.cbxsoreeyes.TabIndex = 19;
            this.cbxsoreeyes.Text = "Sore Eyes";
            this.cbxsoreeyes.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.txtpieces);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.lblasdasdas);
            this.panel2.Controls.Add(this.txtday);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtmg);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtmed);
            this.panel2.Location = new System.Drawing.Point(28, 352);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(537, 145);
            this.panel2.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(422, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 15);
            this.label8.TabIndex = 35;
            this.label8.Text = "Pieces";
            // 
            // txtpieces
            // 
            this.txtpieces.Location = new System.Drawing.Point(404, 58);
            this.txtpieces.Name = "txtpieces";
            this.txtpieces.Size = new System.Drawing.Size(96, 20);
            this.txtpieces.TabIndex = 34;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(404, 95);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(96, 39);
            this.button5.TabIndex = 33;
            this.button5.Text = "ADD";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // lblasdasdas
            // 
            this.lblasdasdas.AutoSize = true;
            this.lblasdasdas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblasdasdas.Location = new System.Drawing.Point(333, 40);
            this.lblasdasdas.Name = "lblasdasdas";
            this.lblasdasdas.Size = new System.Drawing.Size(28, 15);
            this.lblasdasdas.TabIndex = 32;
            this.lblasdasdas.Text = "Day";
            // 
            // txtday
            // 
            this.txtday.Location = new System.Drawing.Point(302, 58);
            this.txtday.Name = "txtday";
            this.txtday.Size = new System.Drawing.Size(96, 20);
            this.txtday.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(239, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 15);
            this.label7.TabIndex = 26;
            this.label7.Text = "mg";
            // 
            // txtmg
            // 
            this.txtmg.Location = new System.Drawing.Point(215, 58);
            this.txtmg.Name = "txtmg";
            this.txtmg.Size = new System.Drawing.Size(81, 20);
            this.txtmg.TabIndex = 23;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(73, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 15);
            this.label6.TabIndex = 20;
            this.label6.Text = "Medicines";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 19;
            this.label2.Text = "Prescription";
            // 
            // txtmed
            // 
            this.txtmed.Location = new System.Drawing.Point(15, 58);
            this.txtmed.Name = "txtmed";
            this.txtmed.Size = new System.Drawing.Size(194, 20);
            this.txtmed.TabIndex = 2;
            // 
            // cbxstomachache
            // 
            this.cbxstomachache.AutoSize = true;
            this.cbxstomachache.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxstomachache.Location = new System.Drawing.Point(207, 53);
            this.cbxstomachache.Name = "cbxstomachache";
            this.cbxstomachache.Size = new System.Drawing.Size(105, 19);
            this.cbxstomachache.TabIndex = 17;
            this.cbxstomachache.Text = "Stomach ache";
            this.cbxstomachache.UseVisualStyleBackColor = true;
            // 
            // cbxvomiting
            // 
            this.cbxvomiting.AutoSize = true;
            this.cbxvomiting.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxvomiting.Location = new System.Drawing.Point(23, 53);
            this.cbxvomiting.Name = "cbxvomiting";
            this.cbxvomiting.Size = new System.Drawing.Size(74, 19);
            this.cbxvomiting.TabIndex = 16;
            this.cbxvomiting.Text = "Vomiting";
            this.cbxvomiting.UseVisualStyleBackColor = true;
            // 
            // cbxallergies
            // 
            this.cbxallergies.AutoSize = true;
            this.cbxallergies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxallergies.Location = new System.Drawing.Point(207, 76);
            this.cbxallergies.Name = "cbxallergies";
            this.cbxallergies.Size = new System.Drawing.Size(73, 19);
            this.cbxallergies.TabIndex = 15;
            this.cbxallergies.Text = "Allergies";
            this.cbxallergies.UseVisualStyleBackColor = true;
            // 
            // cbxcough
            // 
            this.cbxcough.AutoSize = true;
            this.cbxcough.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxcough.Location = new System.Drawing.Point(23, 99);
            this.cbxcough.Name = "cbxcough";
            this.cbxcough.Size = new System.Drawing.Size(62, 19);
            this.cbxcough.TabIndex = 14;
            this.cbxcough.Text = "Cough";
            this.cbxcough.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(408, 531);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 13;
            this.button3.Text = "Cancel";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(500, 531);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Done";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Patient\'s Problem/s";
            // 
            // cbxheadache
            // 
            this.cbxheadache.AutoSize = true;
            this.cbxheadache.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxheadache.Location = new System.Drawing.Point(23, 76);
            this.cbxheadache.Name = "cbxheadache";
            this.cbxheadache.Size = new System.Drawing.Size(83, 19);
            this.cbxheadache.TabIndex = 10;
            this.cbxheadache.Text = "Headache";
            this.cbxheadache.UseVisualStyleBackColor = true;
            // 
            // txtfinal
            // 
            this.txtfinal.Location = new System.Drawing.Point(23, 260);
            this.txtfinal.Multiline = true;
            this.txtfinal.Name = "txtfinal";
            this.txtfinal.Size = new System.Drawing.Size(274, 64);
            this.txtfinal.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 244);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Doctors Final Diagnosis";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Possible Diagnosis";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(1048, 40);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(185, 20);
            this.dateTimePicker1.TabIndex = 7;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(518, 14);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(81, 26);
            this.button2.TabIndex = 8;
            this.button2.Text = "SEARCH";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(335, 18);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(169, 20);
            this.txtsearch.TabIndex = 9;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(17, 106);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(639, 547);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lvw);
            this.tabPage1.Controls.Add(this.txtsearch);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(631, 521);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lvw1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(631, 521);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lvw1
            // 
            this.lvw1.CheckBoxes = true;
            this.lvw1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13});
            this.lvw1.GridLines = true;
            this.lvw1.Location = new System.Drawing.Point(29, 66);
            this.lvw1.Name = "lvw1";
            this.lvw1.Size = new System.Drawing.Size(573, 389);
            this.lvw1.TabIndex = 16;
            this.lvw1.UseCompatibleStateImageBehavior = false;
            this.lvw1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Medicine";
            this.columnHeader10.Width = 200;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Mg";
            this.columnHeader11.Width = 65;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Day";
            this.columnHeader12.Width = 140;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Piece/s";
            this.columnHeader13.Width = 95;
            // 
            // picback
            // 
            this.picback.Image = ((System.Drawing.Image)(resources.GetObject("picback.Image")));
            this.picback.Location = new System.Drawing.Point(12, 12);
            this.picback.Name = "picback";
            this.picback.Size = new System.Drawing.Size(37, 31);
            this.picback.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picback.TabIndex = 79;
            this.picback.TabStop = false;
            this.picback.Click += new System.EventHandler(this.picback_Click);
            // 
            // Patient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.ClientSize = new System.Drawing.Size(1283, 679);
            this.Controls.Add(this.picback);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Patient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "v";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picback)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvw;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox cbxheadache;
        private System.Windows.Forms.TextBox txtfinal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.CheckBox cbxstomachache;
        private System.Windows.Forms.CheckBox cbxvomiting;
        private System.Windows.Forms.CheckBox cbxallergies;
        private System.Windows.Forms.CheckBox cbxcough;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtmed;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.CheckBox cbxsoarthroat;
        private System.Windows.Forms.CheckBox cbxshivering;
        private System.Windows.Forms.CheckBox cbxfever;
        private System.Windows.Forms.CheckBox cbxdiarrhea;
        private System.Windows.Forms.CheckBox cbxsoreeyes;
        private System.Windows.Forms.TextBox txtdiagnosis1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label lblasdasdas;
        private System.Windows.Forms.TextBox txtday;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtmg;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListView lvw1;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtpieces;
        private System.Windows.Forms.PictureBox picback;
    }
}
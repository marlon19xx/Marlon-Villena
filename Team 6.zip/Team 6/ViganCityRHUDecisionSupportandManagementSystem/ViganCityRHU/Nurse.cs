﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ViganCityRHU
{
    public partial class Nurse : Form
    {
        dbconn con = new dbconn();
        public Nurse()
        {
            InitializeComponent();
        }

        private void btndone_Click(object sender, EventArgs e)
        {
            string height = txtheight.Text.Trim().ToString();
            string weight = txtweight.Text.Trim().ToString();
            string temp = txtbtemperature.Text.Trim().ToString();
            string bpressure = mkdbpressure.Text.Trim().ToString();
            
            if (height == "" || weight == "" || temp == "" || bpressure == "")
            {
                MessageBox.Show("Insufficient Information!");
            }
            
            else
            {

                string sqlSelectID = "SELECT `Patient_ID` FROM `patient_info_medical` ORDER BY `Patient_ID` DESC";
                Label lbllastid = new Label();
                con.selectID(sqlSelectID, lbllastid);

                int y, x = Convert.ToInt32(lbllastid.Text.Trim().ToString());
                y = x + 1;

                string sqlInsert = "INSERT INTO `patient_record` (`Patient_ID`, `Height`,`Weight`, `Body_temp`, `Blood_pressure`) VALUES ('" + y + "', '" + height + "','" + weight + "', '" + temp + "', '" + bpressure + "')";

                con.save(sqlInsert);


                MessageBox.Show("Successfully Registered!");
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            ViganCityRHUMainForm a = new ViganCityRHUMainForm();
            a.Show();
            this.Hide();
        }
    }
}

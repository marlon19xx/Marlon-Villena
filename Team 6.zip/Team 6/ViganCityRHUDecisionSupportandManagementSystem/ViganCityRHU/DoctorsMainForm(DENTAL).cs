﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ViganCityRHU
{
    public partial class DoctorsMainForm_DENTAL_ : Form
    {
        public DoctorsMainForm_DENTAL_()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void picback_Click(object sender, EventArgs e)
        {
            DoctorsMainForm a = new DoctorsMainForm();
            a.Show();
            this.Hide();
        }
    }
}

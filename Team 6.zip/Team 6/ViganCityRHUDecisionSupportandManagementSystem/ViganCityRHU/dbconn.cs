﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;

namespace ViganCityRHU
{
 
    class dbconn
    {
        String str = @"server = localhost; database = dbhealthcenter; userid = root; password = ;";
        MySqlConnection con = null;

        public string encryption(string pass)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute hash from the bytesof text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(pass));

            //get hash result after compute it
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into 2 hexadecimal digits
                //for each byte
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }

        public void save(string sqlInsert)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = new MySqlCommand(sqlInsert, con);
                cmd.ExecuteNonQuery();

            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

        public void selectwho(string sqlSelect, Label lbluser, Label lblpass)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                MySqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    lbluser.Text = rdr.GetValue(0).ToString();
                    lblpass.Text = rdr.GetValue(1).ToString();

                }



            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

        public void selectID(string sqlSelectID, Label lbllastid)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelectID;
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                lbllastid.Text = rdr.GetValue(0).ToString();
            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

        public void selectproductcode(string sqlSelect, Label lblcode)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                lblcode.Text = rdr.GetValue(0).ToString();
            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

        public void selectproductcode1(string sqlSelect1, Label lblcode1)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect1;
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();

                lblcode1.Text = rdr.GetValue(0).ToString();
            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

       public void select(string sqlSelect2, ListView lvw)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect2;
                MySqlDataReader rdr = cmd.ExecuteReader();



                while (rdr.Read())
                {
                    ListViewItem lvwsor = new ListViewItem();
                    lvwsor.Text = rdr.GetValue(0).ToString();
                    lvwsor.SubItems.Add(rdr.GetValue(1).ToString() + " " + rdr.GetValue(2).ToString() + " " + rdr.GetValue(3).ToString() + " " + rdr.GetValue(4).ToString()); 
                    lvwsor.SubItems.Add(rdr.GetValue(5).ToString());
                    lvwsor.SubItems.Add(rdr.GetValue(6).ToString());
                    lvwsor.SubItems.Add(rdr.GetValue(7).ToString() + " " + rdr.GetValue(8).ToString() + " " + rdr.GetValue(9).ToString() + " " + rdr.GetValue(10).ToString());
                   
                    lvwsor.SubItems.Add(rdr.GetValue(11).ToString());
                    lvwsor.SubItems.Add(rdr.GetValue(12).ToString());
                    lvwsor.SubItems.Add(rdr.GetValue(13).ToString());
                    lvwsor.SubItems.Add(rdr.GetValue(14).ToString());
                    lvwsor=
                    lvw.Items.Add(lvwsor);

                }
            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

       public void selectwho1(string sqlSelect1, Label lbluser1, Label lblpass1)
       {

           try
           {
               con = new MySqlConnection(str);
               con.Open(); //open the connection
               MySqlCommand cmd = con.CreateCommand();
               cmd.CommandText = sqlSelect1;
               MySqlDataReader rdr = cmd.ExecuteReader();
               if (rdr.Read())
               {
                   lbluser1.Text = rdr.GetValue(0).ToString();
                   lblpass1.Text = rdr.GetValue(1).ToString();

               }



           } //captures and displays any MySql errors that will occur
           catch (MySqlException err)
           {
               Console.WriteLine("Error: " + err.ToString());
           }
           finally
           {
               if (con != null)
               {
                   con.Close(); //safely close conn
               }
           }
       }

       public void selectwho2(string sqlSelect2, Label lbluser2, Label lblpass2)
       {
           try
           {
               con = new MySqlConnection(str);
               con.Open(); //open the connection
               MySqlCommand cmd = con.CreateCommand();
               cmd.CommandText = sqlSelect2;
               MySqlDataReader rdr = cmd.ExecuteReader();
               if (rdr.Read())
               {
                   lbluser2.Text = rdr.GetValue(0).ToString();
                   lblpass2.Text = rdr.GetValue(1).ToString();

               }



           } //captures and displays any MySql errors that will occur
           catch (MySqlException err)
           {
               Console.WriteLine("Error: " + err.ToString());
           }
           finally
           {
               if (con != null)
               {
                   con.Close(); //safely close conn
               }
           }
       }

       public void selectcodefortransac(string sqlSelect, Label lblcode)
       {
           try
           {
               con = new MySqlConnection(str);
               con.Open(); //open the connection
               MySqlCommand cmd = con.CreateCommand();
               cmd.CommandText = sqlSelect;
               MySqlDataReader rdr = cmd.ExecuteReader();
               if (rdr.Read())
               {
                   lblcode.Text = rdr.GetValue(0).ToString();
                  

               }



           } //captures and displays any MySql errors that will occur
           catch (MySqlException err)
           {
               Console.WriteLine("Error: " + err.ToString());
           }
           finally
           {
               if (con != null)
               {
                   con.Close(); //safely close conn
               }
           }
       }

       public void select(string sqlSelectq, Label lblnoofstocks)
       {
           try
           {
               con = new MySqlConnection(str);
               con.Open(); //open the connection
               MySqlCommand cmd = con.CreateCommand();
               cmd.CommandText = sqlSelectq;
               MySqlDataReader rdr = cmd.ExecuteReader();
               if (rdr.Read())
               {
                   lblnoofstocks.Text = rdr.GetValue(0).ToString();
                  

               }



           } //captures and displays any MySql errors that will occur
           catch (MySqlException err)
           {
               Console.WriteLine("Error: " + err.ToString());
           }
           finally
           {
               if (con != null)
               {
                   con.Close(); //safely close conn
               }
           }
       }


       public void selectAGAIN(string sqlSelectagain, ListView lvw, string brand, int qty)
       {
           try
           {
               con = new MySqlConnection(str);
               con.Open(); //open the connection
               MySqlCommand cmd = con.CreateCommand();
               cmd.CommandText = sqlSelectagain;
               MySqlDataReader rdr = cmd.ExecuteReader();



               while (rdr.Read())
               {
                   ListViewItem lvwsor = new ListViewItem();
                   lvwsor.Text = rdr.GetValue(0).ToString();
                   lvwsor.SubItems.Add(rdr.GetValue(1).ToString());
                   lvwsor.SubItems.Add(brand.ToString());
                   lvwsor.SubItems.Add(qty.ToString());
                   lvw.Items.Add(lvwsor);

               }
           } //captures and displays any MySql errors that will occur
           catch (MySqlException err)
           {
               Console.WriteLine("Error: " + err.ToString());
           }
           finally
           {
               if (con != null)
               {
                   con.Close(); //safely close conn
               }
           }
       }

       public void selectstockspowers(string sqlSelect, Label lblstocks)
       {
           try
           {
               con = new MySqlConnection(str);
               con.Open(); //open the connection
               MySqlCommand cmd = con.CreateCommand();
               cmd.CommandText = sqlSelect;
               MySqlDataReader rdr = cmd.ExecuteReader();
               if (rdr.Read())
               {

                   lblstocks.Text = rdr.GetValue(0).ToString();


               }



           } //captures and displays any MySql errors that will occur
           catch (MySqlException err)
           {
               Console.WriteLine("Error: " + err.ToString());
           }
           finally
           {
               if (con != null)
               {
                   con.Close(); //safely close conn
               }
           }
       }

      public void selecx(string sqlSelectx, Label lblsold)
       {
           try
           {
               con = new MySqlConnection(str);
               con.Open(); //open the connection
               MySqlCommand cmd = con.CreateCommand();
               cmd.CommandText = sqlSelectx;
               MySqlDataReader rdr = cmd.ExecuteReader();



               while (rdr.Read())
               {
                   lblsold.Text = rdr.GetValue(0).ToString();

               }
           } //captures and displays any MySql errors that will occur
           catch (MySqlException err)
           {
               Console.WriteLine("Error: " + err.ToString());
           }
           finally
           {
               if (con != null)
               {
                   con.Close(); //safely close conn
               }
           }
       }

      public void update(string sqlUpdate)
      {
          try
          {
              con = new MySqlConnection(str);
              con.Open(); //open the connection
              MySqlCommand cmd = new MySqlCommand(sqlUpdate, con);
              cmd.ExecuteNonQuery();
          } //captures and displays any MySql errors that will occur
          catch (MySqlException err)
          {
              Console.WriteLine("Error: " + err.ToString());
          }
          finally
          {
              if (con != null)
              {
                  con.Close(); //safely close conn
              }
          }
      }

      public void selectproductfortransac(string sqlSelectprod, ListView lviprod)
      {
          try
          {
              con = new MySqlConnection(str);
              con.Open(); //open the connection
              MySqlCommand cmd = con.CreateCommand();
              cmd.CommandText = sqlSelectprod;
              MySqlDataReader rdr = cmd.ExecuteReader();



              while (rdr.Read())
              {
                  ListViewItem lvwsor = new ListViewItem();
                  lvwsor.Text = rdr.GetValue(0).ToString();
                  lvwsor.SubItems.Add(rdr.GetValue(1).ToString());
                  lvwsor.SubItems.Add(rdr.GetValue(2).ToString());
                  lvwsor.SubItems.Add(rdr.GetValue(3).ToString());
                  lviprod.Items.Add(lvwsor);

              }
          } //captures and displays any MySql errors that will occur
          catch (MySqlException err)
          {
              Console.WriteLine("Error: " + err.ToString());
          }
          finally
          {
              if (con != null)
              {
                  con.Close(); //safely close conn
              }
          }
      }

      public void selectname(string sqlSelectname, TextBox txtcode, TextBox txtname, TextBox txtbrand, TextBox txtqty)
      {
          try
          {
              con = new MySqlConnection(str);
              con.Open(); //open the connection
              MySqlCommand cmd = con.CreateCommand();
              cmd.CommandText = sqlSelectname;
              MySqlDataReader rdr = cmd.ExecuteReader();
              if (rdr.Read())
              {
                  txtcode.Text = rdr.GetValue(0).ToString();
                  txtname.Text = rdr.GetValue(1).ToString();
                  txtbrand.Text = rdr.GetValue(2).ToString();
                  txtqty.Text = rdr.GetValue(3).ToString();


              }



          } //captures and displays any MySql errors that will occur
          catch (MySqlException err)
          {
              Console.WriteLine("Error: " + err.ToString());
          }
          finally
          {
              if (con != null)
              {
                  con.Close(); //safely close conn
              }
          }
      }

      public void selectpcode(string sqlSelectx, Label lblacode)
      {
          try
          {
              con = new MySqlConnection(str);
              con.Open(); //open the connection
              MySqlCommand cmd = con.CreateCommand();
              cmd.CommandText = sqlSelectx;
              MySqlDataReader rdr = cmd.ExecuteReader();
              if (rdr.Read())
              {

                  lblacode.Text = rdr.GetValue(0).ToString();


              }



          } //captures and displays any MySql errors that will occur
          catch (MySqlException err)
          {
              Console.WriteLine("Error: " + err.ToString());
          }
          finally
          {
              if (con != null)
              {
                  con.Close(); //safely close conn
              }
          }
      }

      public void selectstocks(string sqlSelectp, Label lbloldstocks)
      {
          try
          {
              con = new MySqlConnection(str);
              con.Open(); //open the connection
              MySqlCommand cmd = con.CreateCommand();
              cmd.CommandText = sqlSelectp;
              MySqlDataReader rdr = cmd.ExecuteReader();
              if (rdr.Read())
              {

                  lbloldstocks.Text = rdr.GetValue(0).ToString();


              }



          } //captures and displays any MySql errors that will occur
          catch (MySqlException err)
          {
              Console.WriteLine("Error: " + err.ToString());
          }
          finally
          {
              if (con != null)
              {
                  con.Close(); //safely close conn
              }
          }
      }

     public void selectaname(string sqlSelectpname, TextBox txtaname)
      {
          try
          {
              con = new MySqlConnection(str);
              con.Open(); //open the connection
              MySqlCommand cmd = con.CreateCommand();
              cmd.CommandText = sqlSelectpname;
              MySqlDataReader rdr = cmd.ExecuteReader();
              if (rdr.Read())
              {

                 txtaname.Text = rdr.GetValue(0).ToString();


              }



          } //captures and displays any MySql errors that will occur
          catch (MySqlException err)
          {
              Console.WriteLine("Error: " + err.ToString());
          }
          finally
          {
              if (con != null)
              {
                  con.Close(); //safely close conn
              }
          }
      }

    public void selects(string sqlSelect1, Label lblcstocks)
     {
         try
         {
             con = new MySqlConnection(str);
             con.Open(); //open the connection
             MySqlCommand cmd = con.CreateCommand();
             cmd.CommandText = sqlSelect1;
             MySqlDataReader rdr = cmd.ExecuteReader();
             if (rdr.Read())
             {

                 lblcstocks.Text = rdr.GetValue(0).ToString();


             }



         } //captures and displays any MySql errors that will occur
         catch (MySqlException err)
         {
             Console.WriteLine("Error: " + err.ToString());
         }
         finally
         {
             if (con != null)
             {
                 con.Close(); //safely close conn
             }
         }
     }

    public void selectadminforstcoksaddition(string sqlSelect, Label lbluser, Label lblpass)
    {
        try
        {
            con = new MySqlConnection(str);
            con.Open(); //open the connection
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = sqlSelect;
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {

                lbluser.Text = rdr.GetValue(0).ToString();
                lblpass.Text = rdr.GetValue(1).ToString();


            }



        } //captures and displays any MySql errors that will occur
        catch (MySqlException err)
        {
            Console.WriteLine("Error: " + err.ToString());
        }
        finally
        {
            if (con != null)
            {
                con.Close(); //safely close conn
            }
        }
    }

    public void selectallrecords(string sqlSelect3, ListView lvi)
    {
        try
        {
            con = new MySqlConnection(str);
            con.Open(); //open the connection
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = sqlSelect3;
            MySqlDataReader rdr = cmd.ExecuteReader();



            while (rdr.Read())
            {
                ListViewItem lvwsor = new ListViewItem();
                lvwsor.Text = rdr.GetValue(0).ToString();
                lvwsor.SubItems.Add(rdr.GetValue(1).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(2).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(3).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(4).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(5).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(6).ToString());
                lvi.Items.Add(lvwsor);

            }
        } //captures and displays any MySql errors that will occur
        catch (MySqlException err)
        {
            Console.WriteLine("Error: " + err.ToString());
        }
        finally
        {
            if (con != null)
            {
                con.Close(); //safely close conn
            }
        }
    }

    public void selectprodutcode2(string sqlSelect2, Label lblcode1, ListView lvi)
    {
        try
        {
            con = new MySqlConnection(str);
            con.Open(); //open the connection
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = sqlSelect2;
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {

                lblcode1.Text = rdr.GetValue(0).ToString();
            
            }

            while (rdr.Read())
            {
                ListViewItem lvwsor = new ListViewItem();
                lvwsor.Text = rdr.GetValue(1).ToString();
                lvwsor.SubItems.Add(rdr.GetValue(1).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(2).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(3).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(4).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(5).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(7).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(8).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(9).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(10).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(13).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(14).ToString());
                lvi.Items.Add(lvwsor);

            }
        } //captures and displays any MySql errors that will occur
        catch (MySqlException err)
        {
            Console.WriteLine("Error: " + err.ToString());
        }
        finally
        {
            if (con != null)
            {
                con.Close(); //safely close conn
            }
        }
    }

    public void selectproductcode2(string sqlSelect1, Label lblcode1, ListView lvi)
    {
        try
        {
            con = new MySqlConnection(str);
            con.Open(); //open the connection
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = sqlSelect1;
            MySqlDataReader rdr = cmd.ExecuteReader();

            if (rdr.Read())
            {

                lblcode1.Text = rdr.GetValue(0).ToString();

            }

            while (rdr.Read())
            {
                ListViewItem lvwsor = new ListViewItem();
                lvwsor.Text = rdr.GetValue(0).ToString();
                lvwsor.SubItems.Add(rdr.GetValue(1).ToString());
                lvwsor.SubItems.Add(rdr.GetValue(2).ToString());
                lvi.Items.Add(lvwsor);

            }
        } //captures and displays any MySql errors that will occur
        catch (MySqlException err)
        {
            Console.WriteLine("Error: " + err.ToString());
        }
        finally
        {
            if (con != null)
            {
                con.Close(); //safely close conn
            }
        }
    }

    public void selectRecs(string sqlSelect2, ListView lvi_recs)
    {
        try
        {
            con = new MySqlConnection(str);
            con.Open(); //open the connection
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = sqlSelect2;
            MySqlDataReader rdr = cmd.ExecuteReader();
            

            while (rdr.Read())
            {
                ListViewItem lvwsor = new ListViewItem();
                lvwsor.Text = rdr["Patient_ID"].ToString();
                lvwsor.SubItems.Add(rdr["Firstname"].ToString() + " " + rdr["Middlename"].ToString()+ " " +rdr["Lastname"].ToString());
                lvwsor.SubItems.Add(rdr["Age"].ToString());
                lvwsor.SubItems.Add(rdr["Brgy"].ToString() + " " + rdr["City"].ToString() + " " +rdr["Province"].ToString());
                lvwsor.SubItems.Add(rdr["Status"].ToString());
                lvwsor.SubItems.Add(rdr["Citizenship"].ToString());
                lvwsor.SubItems.Add(rdr["Initian_Diagnosis"].ToString());
                lvwsor.SubItems.Add(rdr["Doctor_final_diagnosis"].ToString());
                lvi_recs.Items.Add(lvwsor);

            }
        } //captures and displays any MySql errors that will occur
        catch (MySqlException err)
        {
            Console.WriteLine("Error: " + err.ToString());
        }
        finally
        {
            if (con != null)
            {
                con.Close(); //safely close conn
            }
        }
    }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ViganCityRHU
{
    public partial class Transaction : Form
    {
        dbconn con = new dbconn();
        public Transaction()
        {
            InitializeComponent();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {

            string code = txtproductcode.Text.Trim().ToString();

          

            string sqlSelect = "SELECT * FROM `Products` WHERE `Product_Code` = '" + code + "'";
            con.selectcodefortransac(sqlSelect, lblcode);

            string sqlSelectq = "SELECT `Stocks` FROM `Products` WHERE `Product_Code` = '" + code + "'";
            con.select(sqlSelectq, lblnoofstocks);
            string none = "0";



            if (none == lblnoofstocks.Text)
            {
                MessageBox.Show("This Item Has 0 Stock");
            }

            else if (lblcode.Text == code)
            {
                string sqlSelectname = "SELECT * FROM `Products` WHERE `Product_Code` = '" + lblcode.Text + "'";
                con.selectname(sqlSelectname, txtcode, txtname, txtbrand, txtqty );


            }
            else
            {
                MessageBox.Show("ERROR: Product Code Not Found");
            }
        }

        private void btndone_Click(object sender, EventArgs e)
        {
            string sqlSelectID = "SELECT `ID` FROM `Customers_Records` ORDER BY `ID` DESC";
            Label lbllastid = new Label();
            con.selectID(sqlSelectID, lbllastid);
            int y, x = Convert.ToInt32(lbllastid.Text.Trim().ToString());
            y = x + 1;


        }

        private void btncompute_Click(object sender, EventArgs e)
        {
            if (txtqty.Text == "" || txtcode.Text == "")
            {
                MessageBox.Show("Insuficient Information");
            }

            else if (lblcode.Text == txtcode.Text)
            {
                int qty;
                string brand;
                brand = txtbrand.Text.Trim().ToString();
                qty = Convert.ToInt32(txtqty.Text.Trim().ToString());
                
                string sqlSelectagain = "SELECT * FROM `Products` WHERE `Product_Code` = '" + txtcode.Text + "'";
                con.selectAGAIN(sqlSelectagain, lvw, brand, qty);


                string sqlSelect = "SELECT `Stocks` FROM `Products` WHERE `Product_Code` = '" + txtcode.Text + "'";
                con.selectstockspowers(sqlSelect, lblstocks);

                double newstocks;
                double oldstocks;
                oldstocks = Convert.ToDouble(lblstocks.Text.Trim().ToString());


                newstocks = oldstocks - qty;

                string sqlUpdate = "UPDATE `Products` SET `Stocks` = '" + newstocks + "' WHERE `Product_Code` = '" + txtcode.Text + "'";
                con.update(sqlUpdate);

                string sqlSelectx = "SELECT `Released` FROM `Products` WHERE `Product_Code` = '" + txtcode.Text + "'";
                con.selecx(sqlSelectx, lblsold);

                int sold, newsold;
                sold = Convert.ToInt32(lblsold.Text.ToString());

                newsold = sold + qty;

                string sqlUpdate1 = "UPDATE `Products` SET `Sold` = '" + newsold + "' WHERE `Product_Code` = '" + txtcode.Text + "'";
                con.update(sqlUpdate1);

        }
    }

        private void Transaction_Load(object sender, EventArgs e)
        {
            string sqlSelectprod = "SELECT * FROM `Products`";
            con.selectproductfortransac(sqlSelectprod, lviprod);
        }

        private void btnaddstocks_Click(object sender, EventArgs e)
        {

            string cname = txtcompanyname.Text.Trim().ToString();
            string cadd = txtcompanyadd.Text.Trim().ToString();
            string cowner = txtcompanyowner.Text.Trim().ToString();
            string tin = txttin.Text.Trim().ToString();
            string code = txtacode.Text.Trim().ToString();
            string name = txtaname.Text.Trim().ToString();
            string stocks = txtastocks.Text.Trim().ToString();
            string totalamount = txtstocksamount.Text.Trim().ToString();
            string sqlSelect = "SELECT `Username`, `Password` FROM `Pharmacist`";
            con.selectadminforstcoksaddition(sqlSelect, lbluser, lblpass);



            string sqlSelectx = "SELECT * FROM `Supplier` WHERE `Product_Code` = '" + code + "'";
            con.selectpcode(sqlSelectx, lblacode);
            
            if (cname == "" || cadd == "" || cowner == "" || tin == "" || stocks == "" )
            {
                MessageBox.Show("Insufficient Information!");
            }
            else if (lbluser.Text == "false" && lblpass.Text == "false")
            {
                MessageBox.Show("Wrong Information");
            }

            else if (lblacode.Text == code || code == "")
            {
                MessageBox.Show("ERROR:Product Code Not Found");
            }
            else if (totalamount == "" || totalamount == "00.0" || totalamount == "00." || totalamount == "00" || totalamount == "0" || totalamount == "00.00" || totalamount == "0.0" || totalamount == "0.00" || totalamount == ".00")
            {
                MessageBox.Show("No Total Amount Added");
            }
            else
            {
                 string sqlSelectp = "SELECT `Stocks` FROM `Products` WHERE `Product_Code` = '" + lblacode.Text + "'";
                con.selectstocks(sqlSelectp, lbloldstocks);

                double totalstocksnow;
                double oldstocks;
                double stock;

                stock = Convert.ToDouble(txtastocks.Text.Trim().ToString());
                oldstocks = Convert.ToDouble(lbloldstocks.Text.Trim().ToString());


                totalstocksnow = oldstocks + stock;
                lbltotalstocksnow.Text = totalstocksnow.ToString();


                string sqlUpdate1 = "UPDATE `Products` SET `Stocks` = '" + lbltotalstocksnow.Text + "' WHERE `Product_Code` = '" + lblacode.Text + "'";
                con.update(sqlUpdate1);


                string sqlSelectpname = "SELECT `Product_Name` FROM `Products` WHERE `Product_Code` = '" + lblacode.Text + "'";
                con.selectaname(sqlSelectpname, txtaname);




                string sqlInsert = "INSERT INTO `Supplier` (`Company_Name`,`Owner`, `Address`, `Tin`, `Product_Code`, `Product_Name`, `Stocks_Add`, `Total_Amount`) VALUES ('" + cname + "','" + cadd + "', '" + cowner + "', '" + tin + "', '" + code + "', '" + txtaname.Text + "', '" + stocks + "', '" + totalamount + "')";
                con.save(sqlInsert);



                string sqlSelect1 = "SELECT `Stocks` FROM `Products` WHERE `Product_Code` = '" + lblacode.Text + "'";
                con.selects(sqlSelect1, lblcstocks);



                double totalstocksnow1;
                double oldstocks1;
     

       
                oldstocks1 = Convert.ToDouble(lblcstocks.Text.Trim().ToString());


                totalstocksnow1 = oldstocks1 + stock;
                lblcstocks.Text = totalstocksnow1.ToString();



                string sqlUpdate = "UPDATE `Products` SET `Stocks` = '" + lblcstocks.Text + "' WHERE `Product_Code` = '" + lblacode.Text + "'";
                con.update(sqlUpdate);


                MessageBox.Show("Stocks Successfully Added");

        }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            ViganCityRHUMainForm a = new ViganCityRHUMainForm();
            a.Show();
            this.Hide();
        }
    }
}

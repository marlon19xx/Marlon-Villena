﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ViganCityRHU
{
    public partial class Patient : Form
    {
        dbconn con = new dbconn();
        public Patient()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem eachItem in lvw.Items)
            {

                {

                    lvw.Items.Remove(eachItem);

                }
            }


            Label lblcode = new Label();
            Label lblcode1 = new Label();
            string code = txtsearch.Text.Trim().ToString();


            /*string sqlSelect = "SELECT * FROM `Patient_info_dental` WHERE `Patient_ID` = '" + code + "'";
            con.selectproductcode(sqlSelect, lblcode);*/

            string sqlSelect1 = "SELECT * FROM `Patient_info_medical` WHERE `Patient_ID` = '" + code + "'";
            con.selectproductcode1(sqlSelect1, lblcode1);


            if (code == lblcode1.Text)
            {




                string sqlSelect2 = "SELECT * FROM `Patient_info_medical` WHERE `Patient_ID` = '" + code + "'";
                con.select(sqlSelect2, lvw);

            }

            else
            {
                MessageBox.Show("ID Not Found");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (cbxvomiting.Checked == true && cbxstomachache.Checked == true && cbxdiarrhea.Checked == true && cbxfever.Checked == true)
            {
                txtdiagnosis1.Text = "Apendicitis";

            }

            if (cbxvomiting.Checked == true && cbxstomachache.Checked == true && cbxdiarrhea.Checked == true)
            {
                txtdiagnosis1.Text = "Apendicitis";

            }
            if (cbxvomiting.Checked == true && cbxstomachache.Checked == true)
            {
                txtdiagnosis1.Text = "Apendicitis";

            }


            if (cbxheadache.Checked == true && cbxshivering.Checked == true && cbxvomiting.Checked == true && cbxcough.Checked == true && cbxdiarrhea.Checked == true)
            {
                txtdiagnosis1.Text = "Fever";

            }


            if (cbxheadache.Checked == true && cbxshivering.Checked == true && cbxvomiting.Checked == true && cbxcough.Checked == true)
            {
                txtdiagnosis1.Text = "Fever";

            }


            if (cbxheadache.Checked == true && cbxshivering.Checked == true && cbxvomiting.Checked == true)
            {
                txtdiagnosis1.Text = "Fever";

            }

            if (cbxshivering.Checked == true && cbxvomiting.Checked == true)
            {
                txtdiagnosis1.Text = "Fever";

            }

            if (cbxfever.Checked == true && cbxheadache.Checked == true && cbxsoarthroat.Checked == true && cbxcough.Checked == true)
            {
                txtdiagnosis1.Text = "Flu";

            }

            if (cbxsoarthroat.Checked == true && cbxheadache.Checked == true && cbxcough.Checked == true)
            {
                txtdiagnosis1.Text = "Tonsilitis";

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int o = 0; o < lvw.Items.Count; o++)
            {
                string sqlInsert = "INSERT INTO `Patient_record` (`Patient_ID`,`Initial_Diagnosis`, `Doctors_final_diagnosis`) VALUES ('" + lvw.Items[o].SubItems[0].Text + "','" + txtdiagnosis1.Text + "', '" + txtfinal.Text + "')";

                con.save(sqlInsert);
            }


            for (int o = 0; o < lvw1.Items.Count; o++)
            {
                string sqlInsert = "INSERT INTO `Prescription` (`Patient_ID`,`Medicine`, `Dosage`, `Days`, `Pieces`) VALUES ('" + lvw.Items[0].SubItems[0].Text + "','" + lvw1.Items[o].SubItems[0].Text + "', '" + lvw1.Items[o].SubItems[1].Text + "', '" + lvw1.Items[o].SubItems[2].Text + "', '" + lvw1.Items[o].SubItems[3].Text + "')";

                con.save(sqlInsert);
            }





        }

        private void button5_Click(object sender, EventArgs e)
        {

            ListViewItem lvwsor = new ListViewItem();
            lvwsor.Text = txtmed.Text;
            lvwsor.SubItems.Add(txtmg.Text.ToString());
            lvwsor.SubItems.Add(txtday.Text.ToString());
            lvwsor.SubItems.Add(txtpieces.Text.ToString());
            lvw1.Items.Add(lvwsor);
        }

        private void picback_Click(object sender, EventArgs e)
        {
            DoctorsMainForm a = new DoctorsMainForm();
            a.Show();
            this.Hide();
        }



   
    }
}

﻿namespace ViganCityRHU
{
    partial class Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Transaction));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lblfullcashname = new System.Windows.Forms.Label();
            this.lblext = new System.Windows.Forms.Label();
            this.lblcashlname = new System.Windows.Forms.Label();
            this.lblcashmname = new System.Windows.Forms.Label();
            this.lblcashfname = new System.Windows.Forms.Label();
            this.lblcashier = new System.Windows.Forms.Label();
            this.lblcustomersname = new System.Windows.Forms.Label();
            this.lblCustomersID = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.lvi = new System.Windows.Forms.ListView();
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvw = new System.Windows.Forms.ListView();
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtcustomersname = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtuser = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lviprod = new System.Windows.Forms.ListView();
            this.label26 = new System.Windows.Forms.Label();
            this.lblnoofstocks = new System.Windows.Forms.Label();
            this.lbllastCID = new System.Windows.Forms.Label();
            this.lbllastid = new System.Windows.Forms.Label();
            this.lblcstocks = new System.Windows.Forms.Label();
            this.lblstocks = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblpass = new System.Windows.Forms.Label();
            this.btnaddstocks = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lbluser = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.btncleartransac = new System.Windows.Forms.Button();
            this.lblcode = new System.Windows.Forms.Label();
            this.btnaclear = new System.Windows.Forms.Button();
            this.lbltotalstocksnow = new System.Windows.Forms.Label();
            this.lbloldstocks = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblacode = new System.Windows.Forms.Label();
            this.txttin = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtcompanyadd = new System.Windows.Forms.TextBox();
            this.txtcompanyname = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtcompanyowner = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtastocks = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtstocksamount = new System.Windows.Forms.TextBox();
            this.txtacode = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtaname = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnsearch = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btndone = new System.Windows.Forms.Button();
            this.txtproductcode = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.txtbrand = new System.Windows.Forms.TextBox();
            this.txtcode = new System.Windows.Forms.TextBox();
            this.btncompute = new System.Windows.Forms.Button();
            this.txtqty = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblsold = new System.Windows.Forms.Label();
            this.tabPage3.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lblfullcashname);
            this.tabPage3.Controls.Add(this.lblext);
            this.tabPage3.Controls.Add(this.lblcashlname);
            this.tabPage3.Controls.Add(this.lblcashmname);
            this.tabPage3.Controls.Add(this.lblcashfname);
            this.tabPage3.Controls.Add(this.lblcashier);
            this.tabPage3.Controls.Add(this.lblcustomersname);
            this.tabPage3.Controls.Add(this.lblCustomersID);
            this.tabPage3.Controls.Add(this.label36);
            this.tabPage3.Controls.Add(this.label35);
            this.tabPage3.Controls.Add(this.lvi);
            this.tabPage3.Controls.Add(this.label29);
            this.tabPage3.Controls.Add(this.label28);
            this.tabPage3.Controls.Add(this.label27);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(704, 545);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Customer\'s Receit:";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lblfullcashname
            // 
            this.lblfullcashname.AutoSize = true;
            this.lblfullcashname.Location = new System.Drawing.Point(518, 91);
            this.lblfullcashname.Name = "lblfullcashname";
            this.lblfullcashname.Size = new System.Drawing.Size(37, 13);
            this.lblfullcashname.TabIndex = 87;
            this.lblfullcashname.Text = "_____";
            // 
            // lblext
            // 
            this.lblext.AutoSize = true;
            this.lblext.Location = new System.Drawing.Point(612, 37);
            this.lblext.Name = "lblext";
            this.lblext.Size = new System.Drawing.Size(13, 13);
            this.lblext.TabIndex = 86;
            this.lblext.Text = "_";
            // 
            // lblcashlname
            // 
            this.lblcashlname.AutoSize = true;
            this.lblcashlname.Location = new System.Drawing.Point(669, 37);
            this.lblcashlname.Name = "lblcashlname";
            this.lblcashlname.Size = new System.Drawing.Size(13, 13);
            this.lblcashlname.TabIndex = 85;
            this.lblcashlname.Text = "_";
            // 
            // lblcashmname
            // 
            this.lblcashmname.AutoSize = true;
            this.lblcashmname.Location = new System.Drawing.Point(650, 37);
            this.lblcashmname.Name = "lblcashmname";
            this.lblcashmname.Size = new System.Drawing.Size(13, 13);
            this.lblcashmname.TabIndex = 84;
            this.lblcashmname.Text = "_";
            // 
            // lblcashfname
            // 
            this.lblcashfname.AutoSize = true;
            this.lblcashfname.Location = new System.Drawing.Point(631, 37);
            this.lblcashfname.Name = "lblcashfname";
            this.lblcashfname.Size = new System.Drawing.Size(13, 13);
            this.lblcashfname.TabIndex = 83;
            this.lblcashfname.Text = "_";
            // 
            // lblcashier
            // 
            this.lblcashier.AutoSize = true;
            this.lblcashier.Location = new System.Drawing.Point(507, 91);
            this.lblcashier.Name = "lblcashier";
            this.lblcashier.Size = new System.Drawing.Size(13, 13);
            this.lblcashier.TabIndex = 27;
            this.lblcashier.Text = "_";
            // 
            // lblcustomersname
            // 
            this.lblcustomersname.AutoSize = true;
            this.lblcustomersname.Location = new System.Drawing.Point(119, 104);
            this.lblcustomersname.Name = "lblcustomersname";
            this.lblcustomersname.Size = new System.Drawing.Size(37, 13);
            this.lblcustomersname.TabIndex = 26;
            this.lblcustomersname.Text = "_____";
            // 
            // lblCustomersID
            // 
            this.lblCustomersID.AutoSize = true;
            this.lblCustomersID.Location = new System.Drawing.Point(119, 91);
            this.lblCustomersID.Name = "lblCustomersID";
            this.lblCustomersID.Size = new System.Drawing.Size(37, 13);
            this.lblCustomersID.TabIndex = 25;
            this.lblCustomersID.Text = "_____";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(276, 29);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(146, 13);
            this.label36.TabIndex = 24;
            this.label36.Text = "Tamag, Vigan City, Ilocos Sur";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(298, 16);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(91, 13);
            this.label35.TabIndex = 23;
            this.label35.Text = "Uranus Pharmacy";
            // 
            // lvi
            // 
            this.lvi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvi.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader17});
            this.lvi.Location = new System.Drawing.Point(14, 123);
            this.lvi.Name = "lvi";
            this.lvi.Size = new System.Drawing.Size(668, 403);
            this.lvi.TabIndex = 17;
            this.lvi.UseCompatibleStateImageBehavior = false;
            this.lvi.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Product Code:";
            this.columnHeader13.Width = 97;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Product Name:";
            this.columnHeader14.Width = 160;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Brand:";
            this.columnHeader15.Width = 127;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Quantity:";
            this.columnHeader17.Width = 230;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(456, 91);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(45, 13);
            this.label29.TabIndex = 2;
            this.label29.Text = "Cashier:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(21, 104);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(92, 13);
            this.label28.TabIndex = 1;
            this.label28.Text = "Customer\'s Name:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(21, 91);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(75, 13);
            this.label27.TabIndex = 0;
            this.label27.Text = "Customer\'s ID:";
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Brand:";
            this.columnHeader10.Width = 152;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = " Stocks:";
            this.columnHeader12.Width = 230;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Product Name:";
            this.columnHeader9.Width = 145;
            // 
            // lvw
            // 
            this.lvw.CheckBoxes = true;
            this.lvw.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader22,
            this.columnHeader23});
            this.lvw.GridLines = true;
            this.lvw.Location = new System.Drawing.Point(16, 113);
            this.lvw.Name = "lvw";
            this.lvw.Size = new System.Drawing.Size(663, 408);
            this.lvw.TabIndex = 15;
            this.lvw.UseCompatibleStateImageBehavior = false;
            this.lvw.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Product Code:";
            this.columnHeader19.Width = 93;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Product Name:";
            this.columnHeader20.Width = 143;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "Brand";
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "Quantity";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Product Code:";
            this.columnHeader8.Width = 97;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lvw);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(704, 545);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Transactions:";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add(this.txtcustomersname);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox3.Location = new System.Drawing.Point(16, 10);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(454, 88);
            this.groupBox3.TabIndex = 135;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Customer\'s Information";
            // 
            // txtcustomersname
            // 
            this.txtcustomersname.Location = new System.Drawing.Point(177, 34);
            this.txtcustomersname.Name = "txtcustomersname";
            this.txtcustomersname.Size = new System.Drawing.Size(228, 26);
            this.txtcustomersname.TabIndex = 52;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label37.Location = new System.Drawing.Point(31, 40);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(139, 20);
            this.label37.TabIndex = 53;
            this.label37.Text = "Customer\'s Name:";
            // 
            // txtuser
            // 
            this.txtuser.Location = new System.Drawing.Point(129, 25);
            this.txtuser.Name = "txtuser";
            this.txtuser.Size = new System.Drawing.Size(292, 26);
            this.txtuser.TabIndex = 71;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(699, 149);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(712, 571);
            this.tabControl1.TabIndex = 145;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lviprod);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(704, 545);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Products:";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lviprod
            // 
            this.lviprod.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader12});
            this.lviprod.GridLines = true;
            this.lviprod.Location = new System.Drawing.Point(22, 20);
            this.lviprod.Name = "lviprod";
            this.lviprod.Size = new System.Drawing.Size(659, 495);
            this.lviprod.TabIndex = 16;
            this.lviprod.UseCompatibleStateImageBehavior = false;
            this.lviprod.View = System.Windows.Forms.View.Details;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label26.Location = new System.Drawing.Point(30, 28);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(87, 20);
            this.label26.TabIndex = 70;
            this.label26.Text = "Username:";
            // 
            // lblnoofstocks
            // 
            this.lblnoofstocks.AutoSize = true;
            this.lblnoofstocks.Location = new System.Drawing.Point(1058, 33);
            this.lblnoofstocks.Name = "lblnoofstocks";
            this.lblnoofstocks.Size = new System.Drawing.Size(92, 13);
            this.lblnoofstocks.TabIndex = 150;
            this.lblnoofstocks.Text = "StocksperProduct";
            this.lblnoofstocks.Visible = false;
            // 
            // lbllastCID
            // 
            this.lbllastCID.AutoSize = true;
            this.lbllastCID.Location = new System.Drawing.Point(992, 33);
            this.lbllastCID.Name = "lbllastCID";
            this.lbllastCID.Size = new System.Drawing.Size(44, 13);
            this.lbllastCID.TabIndex = 149;
            this.lbllastCID.Text = "last CID";
            this.lbllastCID.Visible = false;
            // 
            // lbllastid
            // 
            this.lbllastid.AutoSize = true;
            this.lbllastid.Location = new System.Drawing.Point(915, 33);
            this.lbllastid.Name = "lbllastid";
            this.lbllastid.Size = new System.Drawing.Size(55, 13);
            this.lbllastid.TabIndex = 146;
            this.lbllastid.Text = "userserser";
            this.lbllastid.Visible = false;
            // 
            // lblcstocks
            // 
            this.lblcstocks.AutoSize = true;
            this.lblcstocks.Location = new System.Drawing.Point(478, 720);
            this.lblcstocks.Name = "lblcstocks";
            this.lblcstocks.Size = new System.Drawing.Size(44, 13);
            this.lblcstocks.TabIndex = 154;
            this.lblcstocks.Text = "cstocks";
            this.lblcstocks.Visible = false;
            // 
            // lblstocks
            // 
            this.lblstocks.AutoSize = true;
            this.lblstocks.Location = new System.Drawing.Point(1156, 33);
            this.lblstocks.Name = "lblstocks";
            this.lblstocks.Size = new System.Drawing.Size(41, 13);
            this.lblstocks.TabIndex = 152;
            this.lblstocks.Text = "label40";
            this.lblstocks.Visible = false;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.MintCream;
            this.groupBox4.Controls.Add(this.txtuser);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.txtpass);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox4.Location = new System.Drawing.Point(194, 492);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(439, 95);
            this.groupBox4.TabIndex = 151;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Pharmacist";
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(128, 54);
            this.txtpass.Name = "txtpass";
            this.txtpass.Size = new System.Drawing.Size(292, 26);
            this.txtpass.TabIndex = 72;
            this.txtpass.UseSystemPasswordChar = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label23.Location = new System.Drawing.Point(35, 54);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(82, 20);
            this.label23.TabIndex = 73;
            this.label23.Text = "Password:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(127, 125);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Location = new System.Drawing.Point(305, 707);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(100, 13);
            this.lblpass.TabIndex = 144;
            this.lblpass.Text = "password validation";
            this.lblpass.Visible = false;
            // 
            // btnaddstocks
            // 
            this.btnaddstocks.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnaddstocks.ForeColor = System.Drawing.Color.Black;
            this.btnaddstocks.Location = new System.Drawing.Point(507, 593);
            this.btnaddstocks.Name = "btnaddstocks";
            this.btnaddstocks.Size = new System.Drawing.Size(117, 50);
            this.btnaddstocks.TabIndex = 134;
            this.btnaddstocks.Text = "ADD";
            this.btnaddstocks.UseVisualStyleBackColor = false;
            this.btnaddstocks.Click += new System.EventHandler(this.btnaddstocks_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Red;
            this.btnLogout.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnLogout.Location = new System.Drawing.Point(28, 675);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(84, 47);
            this.btnLogout.TabIndex = 24;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lbluser
            // 
            this.lbluser.AutoSize = true;
            this.lbluser.Location = new System.Drawing.Point(188, 707);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(101, 13);
            this.lbluser.TabIndex = 143;
            this.lbluser.Text = "username validation";
            this.lbluser.Visible = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(188, 720);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(260, 13);
            this.label22.TabIndex = 142;
            this.label22.Text = "Please Enter Username And Password Of The Admin:";
            this.label22.Visible = false;
            // 
            // btncleartransac
            // 
            this.btncleartransac.ForeColor = System.Drawing.Color.Black;
            this.btncleartransac.Location = new System.Drawing.Point(1663, 669);
            this.btncleartransac.Name = "btncleartransac";
            this.btncleartransac.Size = new System.Drawing.Size(84, 47);
            this.btncleartransac.TabIndex = 137;
            this.btncleartransac.Text = "Clear";
            this.btncleartransac.UseVisualStyleBackColor = true;
            // 
            // lblcode
            // 
            this.lblcode.AutoSize = true;
            this.lblcode.Location = new System.Drawing.Point(1758, 172);
            this.lblcode.Name = "lblcode";
            this.lblcode.Size = new System.Drawing.Size(79, 13);
            this.lblcode.TabIndex = 141;
            this.lblcode.Text = "code validation";
            this.lblcode.Visible = false;
            // 
            // btnaclear
            // 
            this.btnaclear.ForeColor = System.Drawing.Color.Black;
            this.btnaclear.Location = new System.Drawing.Point(399, 593);
            this.btnaclear.Name = "btnaclear";
            this.btnaclear.Size = new System.Drawing.Size(93, 50);
            this.btnaclear.TabIndex = 138;
            this.btnaclear.Text = "Clear";
            this.btnaclear.UseVisualStyleBackColor = true;
            // 
            // lbltotalstocksnow
            // 
            this.lbltotalstocksnow.AutoSize = true;
            this.lbltotalstocksnow.Location = new System.Drawing.Point(449, 304);
            this.lbltotalstocksnow.Name = "lbltotalstocksnow";
            this.lbltotalstocksnow.Size = new System.Drawing.Size(184, 13);
            this.lbltotalstocksnow.TabIndex = 140;
            this.lbltotalstocksnow.Text = "New total stocks for the selected item";
            this.lbltotalstocksnow.Visible = false;
            // 
            // lbloldstocks
            // 
            this.lbloldstocks.AutoSize = true;
            this.lbloldstocks.Location = new System.Drawing.Point(366, 173);
            this.lbloldstocks.Name = "lbloldstocks";
            this.lbloldstocks.Size = new System.Drawing.Size(71, 13);
            this.lbloldstocks.TabIndex = 139;
            this.lbloldstocks.Text = "currentstocks";
            this.lbloldstocks.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.MintCream;
            this.groupBox2.Controls.Add(this.lblacode);
            this.groupBox2.Controls.Add(this.txttin);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.txtcompanyadd);
            this.groupBox2.Controls.Add(this.txtcompanyname);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.txtcompanyowner);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.txtastocks);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.txtstocksamount);
            this.groupBox2.Controls.Add(this.txtacode);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtaname);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(193, 181);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(440, 296);
            this.groupBox2.TabIndex = 133;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Add Stock/s";
            // 
            // lblacode
            // 
            this.lblacode.AutoSize = true;
            this.lblacode.Location = new System.Drawing.Point(14, 141);
            this.lblacode.Name = "lblacode";
            this.lblacode.Size = new System.Drawing.Size(172, 20);
            this.lblacode.TabIndex = 61;
            this.lblacode.Text = "product code validation";
            this.lblacode.Visible = false;
            // 
            // txttin
            // 
            this.txttin.Location = new System.Drawing.Point(129, 114);
            this.txttin.Name = "txttin";
            this.txttin.Size = new System.Drawing.Size(292, 26);
            this.txttin.TabIndex = 59;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label21.Location = new System.Drawing.Point(60, 119);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(62, 20);
            this.label21.TabIndex = 60;
            this.label21.Text = "TIN No.";
            // 
            // txtcompanyadd
            // 
            this.txtcompanyadd.Location = new System.Drawing.Point(129, 84);
            this.txtcompanyadd.Name = "txtcompanyadd";
            this.txtcompanyadd.Size = new System.Drawing.Size(292, 26);
            this.txtcompanyadd.TabIndex = 57;
            // 
            // txtcompanyname
            // 
            this.txtcompanyname.Location = new System.Drawing.Point(129, 23);
            this.txtcompanyname.Name = "txtcompanyname";
            this.txtcompanyname.Size = new System.Drawing.Size(292, 26);
            this.txtcompanyname.TabIndex = 54;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label18.Location = new System.Drawing.Point(-4, 28);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(126, 20);
            this.label18.TabIndex = 53;
            this.label18.Text = "Company Name:";
            // 
            // txtcompanyowner
            // 
            this.txtcompanyowner.Location = new System.Drawing.Point(129, 54);
            this.txtcompanyowner.Name = "txtcompanyowner";
            this.txtcompanyowner.Size = new System.Drawing.Size(292, 26);
            this.txtcompanyowner.TabIndex = 56;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label19.Location = new System.Drawing.Point(63, 59);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 20);
            this.label19.TabIndex = 55;
            this.label19.Text = "Owner:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label20.Location = new System.Drawing.Point(50, 89);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(72, 20);
            this.label20.TabIndex = 58;
            this.label20.Text = "Address:";
            // 
            // txtastocks
            // 
            this.txtastocks.Location = new System.Drawing.Point(129, 227);
            this.txtastocks.Name = "txtastocks";
            this.txtastocks.Size = new System.Drawing.Size(292, 26);
            this.txtastocks.TabIndex = 51;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(56, 232);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(62, 20);
            this.label17.TabIndex = 52;
            this.label17.Text = "Stocks:";
            // 
            // txtstocksamount
            // 
            this.txtstocksamount.Location = new System.Drawing.Point(129, 259);
            this.txtstocksamount.Name = "txtstocksamount";
            this.txtstocksamount.Size = new System.Drawing.Size(292, 26);
            this.txtstocksamount.TabIndex = 49;
            this.txtstocksamount.Text = "00.00";
            // 
            // txtacode
            // 
            this.txtacode.Location = new System.Drawing.Point(129, 164);
            this.txtacode.Name = "txtacode";
            this.txtacode.Size = new System.Drawing.Size(292, 26);
            this.txtacode.TabIndex = 46;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label14.Location = new System.Drawing.Point(12, 169);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(110, 20);
            this.label14.TabIndex = 45;
            this.label14.Text = "Product Code:";
            // 
            // txtaname
            // 
            this.txtaname.Location = new System.Drawing.Point(129, 195);
            this.txtaname.Name = "txtaname";
            this.txtaname.ReadOnly = true;
            this.txtaname.Size = new System.Drawing.Size(292, 26);
            this.txtaname.TabIndex = 48;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label16.Location = new System.Drawing.Point(14, 262);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(108, 20);
            this.label16.TabIndex = 50;
            this.label16.Text = "Total Amount:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label15.Location = new System.Drawing.Point(8, 200);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(114, 20);
            this.label15.TabIndex = 47;
            this.label15.Text = "Product Name:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Image = ((System.Drawing.Image)(resources.GetObject("label11.Image")));
            this.label11.Location = new System.Drawing.Point(158, 59);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(350, 50);
            this.label11.TabIndex = 129;
            this.label11.Text = "VIGAN CITY RURAL HEALTH UNIT\r\nPHARMACY";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Peru;
            this.panel2.Location = new System.Drawing.Point(662, 22);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 733);
            this.panel2.TabIndex = 132;
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.Peru;
            this.btnsearch.Location = new System.Drawing.Point(1754, 56);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(84, 34);
            this.btnsearch.TabIndex = 127;
            this.btnsearch.Text = "OK";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(1444, 63);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 20);
            this.label10.TabIndex = 126;
            this.label10.Text = "Enter Code:";
            // 
            // btndone
            // 
            this.btndone.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btndone.Location = new System.Drawing.Point(1753, 669);
            this.btndone.Name = "btndone";
            this.btndone.Size = new System.Drawing.Size(84, 47);
            this.btndone.TabIndex = 125;
            this.btndone.Text = "DONE";
            this.btndone.UseVisualStyleBackColor = false;
            this.btndone.Click += new System.EventHandler(this.btndone_Click);
            // 
            // txtproductcode
            // 
            this.txtproductcode.Location = new System.Drawing.Point(1544, 61);
            this.txtproductcode.Multiline = true;
            this.txtproductcode.Name = "txtproductcode";
            this.txtproductcode.Size = new System.Drawing.Size(207, 24);
            this.txtproductcode.TabIndex = 124;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Peru;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(12, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(140, 753);
            this.panel1.TabIndex = 128;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MintCream;
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.txtbrand);
            this.panel3.Controls.Add(this.txtcode);
            this.panel3.Controls.Add(this.btncompute);
            this.panel3.Controls.Add(this.txtqty);
            this.panel3.Controls.Add(this.label39);
            this.panel3.Controls.Add(this.txtname);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(1439, 115);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(398, 212);
            this.panel3.TabIndex = 155;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(176, 145);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 47);
            this.button2.TabIndex = 113;
            this.button2.Text = "REMOVE";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // txtbrand
            // 
            this.txtbrand.Location = new System.Drawing.Point(121, 73);
            this.txtbrand.Name = "txtbrand";
            this.txtbrand.ReadOnly = true;
            this.txtbrand.Size = new System.Drawing.Size(271, 20);
            this.txtbrand.TabIndex = 110;
            // 
            // txtcode
            // 
            this.txtcode.Location = new System.Drawing.Point(120, 14);
            this.txtcode.Name = "txtcode";
            this.txtcode.ReadOnly = true;
            this.txtcode.Size = new System.Drawing.Size(271, 20);
            this.txtcode.TabIndex = 44;
            // 
            // btncompute
            // 
            this.btncompute.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btncompute.Location = new System.Drawing.Point(307, 145);
            this.btncompute.Name = "btncompute";
            this.btncompute.Size = new System.Drawing.Size(84, 47);
            this.btncompute.TabIndex = 15;
            this.btncompute.Text = "ADD";
            this.btncompute.UseVisualStyleBackColor = false;
            this.btncompute.Click += new System.EventHandler(this.btncompute_Click);
            // 
            // txtqty
            // 
            this.txtqty.Location = new System.Drawing.Point(120, 108);
            this.txtqty.Name = "txtqty";
            this.txtqty.Size = new System.Drawing.Size(271, 20);
            this.txtqty.TabIndex = 2;
            this.txtqty.Text = "0";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Transparent;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label39.Location = new System.Drawing.Point(32, 73);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(54, 20);
            this.label39.TabIndex = 109;
            this.label39.Text = "Stock:";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(120, 44);
            this.txtname.Name = "txtname";
            this.txtname.ReadOnly = true;
            this.txtname.Size = new System.Drawing.Size(271, 20);
            this.txtname.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label13.Location = new System.Drawing.Point(5, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(110, 20);
            this.label13.TabIndex = 43;
            this.label13.Text = "Product Code:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.Location = new System.Drawing.Point(4, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label3.Location = new System.Drawing.Point(27, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quantity:";
            // 
            // lblsold
            // 
            this.lblsold.AutoSize = true;
            this.lblsold.Location = new System.Drawing.Point(1232, 33);
            this.lblsold.Name = "lblsold";
            this.lblsold.Size = new System.Drawing.Size(26, 13);
            this.lblsold.TabIndex = 156;
            this.lblsold.Text = "sold";
            this.lblsold.Visible = false;
            // 
            // Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.ClientSize = new System.Drawing.Size(1924, 758);
            this.Controls.Add(this.lblsold);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lblnoofstocks);
            this.Controls.Add(this.lbllastCID);
            this.Controls.Add(this.lbllastid);
            this.Controls.Add(this.lblcstocks);
            this.Controls.Add(this.lblstocks);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.btnaddstocks);
            this.Controls.Add(this.lbluser);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.btncleartransac);
            this.Controls.Add(this.lblcode);
            this.Controls.Add(this.btnaclear);
            this.Controls.Add(this.lbltotalstocksnow);
            this.Controls.Add(this.lbloldstocks);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btndone);
            this.Controls.Add(this.txtproductcode);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Transaction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transaction";
            this.Load += new System.EventHandler(this.Transaction_Load);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label lblfullcashname;
        private System.Windows.Forms.Label lblext;
        private System.Windows.Forms.Label lblcashlname;
        private System.Windows.Forms.Label lblcashmname;
        private System.Windows.Forms.Label lblcashfname;
        private System.Windows.Forms.Label lblcashier;
        private System.Windows.Forms.Label lblcustomersname;
        private System.Windows.Forms.Label lblCustomersID;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ListView lvi;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ListView lvw;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtuser;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListView lviprod;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lblnoofstocks;
        private System.Windows.Forms.Label lbllastCID;
        private System.Windows.Forms.Label lbllastid;
        private System.Windows.Forms.Label lblcstocks;
        private System.Windows.Forms.Label lblstocks;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.Button btnaddstocks;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label lbluser;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button btncleartransac;
        private System.Windows.Forms.Label lblcode;
        private System.Windows.Forms.Button btnaclear;
        private System.Windows.Forms.Label lbltotalstocksnow;
        private System.Windows.Forms.Label lbloldstocks;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtcustomersname;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblacode;
        private System.Windows.Forms.TextBox txttin;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtcompanyadd;
        private System.Windows.Forms.TextBox txtcompanyname;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtcompanyowner;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtastocks;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtstocksamount;
        private System.Windows.Forms.TextBox txtacode;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtaname;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btndone;
        private System.Windows.Forms.TextBox txtproductcode;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtbrand;
        private System.Windows.Forms.TextBox txtcode;
        private System.Windows.Forms.Button btncompute;
        private System.Windows.Forms.TextBox txtqty;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblsold;
    }
}
-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2019 at 05:26 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbhealthcenter`
--

-- --------------------------------------------------------

--
-- Table structure for table `appendicitis`
--

CREATE TABLE IF NOT EXISTS `appendicitis` (
  `Symptoms` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appendicitis`
--

INSERT INTO `appendicitis` (`Symptoms`) VALUES
('Stomach ache'),
('Fever'),
('Vomiting '),
('Diarrhea');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `Username` varchar(120) NOT NULL,
  `Password` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`Username`, `Password`) VALUES
('docmarlon', 'c8f759a539858b08e9e46251b1ae9f09');

-- --------------------------------------------------------

--
-- Table structure for table `fever`
--

CREATE TABLE IF NOT EXISTS `fever` (
  `Symptoms` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fever`
--

INSERT INTO `fever` (`Symptoms`) VALUES
('Eye pain '),
('Headache'),
('Shivering'),
('Vomiting'),
('Diarrhea'),
('Cough');

-- --------------------------------------------------------

--
-- Table structure for table `flu`
--

CREATE TABLE IF NOT EXISTS `flu` (
  `Symptoms` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flu`
--

INSERT INTO `flu` (`Symptoms`) VALUES
('Cough'),
('Fever'),
('Headache'),
('Sore throat');

-- --------------------------------------------------------

--
-- Table structure for table `nurse`
--

CREATE TABLE IF NOT EXISTS `nurse` (
  `Username` varchar(120) NOT NULL,
  `Password` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nurse`
--

INSERT INTO `nurse` (`Username`, `Password`) VALUES
('dale', '63a017d3ac56e09d80c939eda9bdbc88');

-- --------------------------------------------------------

--
-- Table structure for table `patient_info_dental`
--

CREATE TABLE IF NOT EXISTS `patient_info_dental` (
  `Patient_ID` int(100) NOT NULL,
  `Firstname` varchar(120) NOT NULL,
  `Middlename` varchar(120) NOT NULL,
  `Lastname` varchar(120) NOT NULL,
  `Ext` varchar(10) NOT NULL,
  `Age` int(5) NOT NULL,
  `Sex` varchar(120) NOT NULL,
  `Brgy` varchar(120) NOT NULL,
  `City` varchar(120) NOT NULL,
  `Province` varchar(120) NOT NULL,
  `Zip` int(10) NOT NULL,
  `Contact` varchar(20) NOT NULL,
  `Date_of_birth` varchar(20) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Citizenship` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_info_dental`
--

INSERT INTO `patient_info_dental` (`Patient_ID`, `Firstname`, `Middlename`, `Lastname`, `Ext`, `Age`, `Sex`, `Brgy`, `City`, `Province`, `Zip`, `Contact`, `Date_of_birth`, `Status`, `Citizenship`) VALUES
(2000, '', '', '', '', 0, '', '', '', '', 0, '0', '0000-00-00', '', ''),
(2001, 't', 't', 't', '', 23, 'Male', 't', 't', 't', 3333, '0', '0000-00-00', 't', 't'),
(2002, 'Emmy', 'Power', 'Yey', '', 21, 'Male', 'Salindeg', 'Vigan City', 'Ilocos Sur', 2700, '0', '0000-00-00', 'Single', 'Filipino'),
(2003, 'b', 'b', 'b', '', 0, 'Male', 'b', 'b', 'b', 1111, '(+63) 111-111-1111', '11/11/1997', 'Single', 'filipino');

-- --------------------------------------------------------

--
-- Table structure for table `patient_info_medical`
--

CREATE TABLE IF NOT EXISTS `patient_info_medical` (
  `Patient_ID` int(100) NOT NULL,
  `Firstname` varchar(120) NOT NULL,
  `Middlename` varchar(120) NOT NULL,
  `Lastname` varchar(120) NOT NULL,
  `Ext` varchar(10) NOT NULL,
  `Age` int(5) NOT NULL,
  `Sex` varchar(120) NOT NULL,
  `Brgy` varchar(120) NOT NULL,
  `City` varchar(120) NOT NULL,
  `Province` varchar(120) NOT NULL,
  `Zip` int(10) NOT NULL,
  `Contact` varchar(20) NOT NULL,
  `Date_of_Birth` varchar(20) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Citizenship` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_info_medical`
--

INSERT INTO `patient_info_medical` (`Patient_ID`, `Firstname`, `Middlename`, `Lastname`, `Ext`, `Age`, `Sex`, `Brgy`, `City`, `Province`, `Zip`, `Contact`, `Date_of_Birth`, `Status`, `Citizenship`) VALUES
(3000, '', '', '', '', 0, '', '', '', '', 0, '0', '0000-00-00', '', ''),
(3001, 'a', 'a', 'a', 'a', 21, 'Male', 'a', 'a', 'a', 2700, '0', '0000-00-00', 'Single', 'Filipino');

-- --------------------------------------------------------

--
-- Table structure for table `patient_record`
--

CREATE TABLE IF NOT EXISTS `patient_record` (
  `Patient_ID` int(100) NOT NULL,
  `Initial_Diagnosis` varchar(500) NOT NULL,
  `Doctors_final_diagnosis` varchar(500) NOT NULL,
  `Height` varchar(10) NOT NULL,
  `Weight` varchar(10) NOT NULL,
  `Body_temp` varchar(10) NOT NULL,
  `Blood_pressure` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_record`
--

INSERT INTO `patient_record` (`Patient_ID`, `Initial_Diagnosis`, `Doctors_final_diagnosis`, `Height`, `Weight`, `Body_temp`, `Blood_pressure`) VALUES
(3001, 'Fever', '1st degree fever', '', '', '', ''),
(3001, 'Apendicitis', 'Acute Apendicitis', '', '', '', ''),
(3001, 'Fever', 'feverssss', '', '', '', ''),
(3001, 'Fever', 'ASdADA', '', '', '', ''),
(3001, 'Fever', 'asdasasd', '', '', '', ''),
(3001, 'Fever', 'asdasasd', '', '', '', ''),
(3001, 'Fever', '123qsasa', '', '', '', ''),
(3001, 'Fever', 'jhbj', '', '', '', ''),
(0, '', '', '12', '12', '12f', '111/11'),
(3002, '', '', '123', '123', '123', '232/13'),
(3001, '', '', '', '', '', ''),
(3002, '', '', '124', '124', '37', '120/80'),
(3001, 'Fever', 'Fever', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

CREATE TABLE IF NOT EXISTS `pharmacist` (
  `Username` varchar(120) NOT NULL,
  `Password` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacist`
--

INSERT INTO `pharmacist` (`Username`, `Password`) VALUES
('emmy', '8a74cdd9f34548a005a6952504f991ad');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE IF NOT EXISTS `prescription` (
  `Patient_ID` int(50) NOT NULL,
  `Medicine` varchar(120) NOT NULL,
  `Dosage` int(50) NOT NULL,
  `Days` int(50) NOT NULL,
  `Pieces` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`Patient_ID`, `Medicine`, `Dosage`, `Days`, `Pieces`) VALUES
(3001, 'paracetamol', 0, 0, 0),
(3001, 'solmux', 0, 0, 0),
(3001, 'solmux', 0, 0, 0),
(3001, 'www', 0, 0, 0),
(3001, 'tryytyty', 0, 0, 0),
(3001, 'www', 0, 0, 0),
(3001, 'tryytyty', 0, 0, 0),
(3001, 'power', 69, 69, 60),
(3001, 'power', 343, 43, 345),
(3001, 'pera', 1, 1, 11),
(3001, 'pejhdhd', 11, 1, 11),
(3001, 'Paracetamol', 500, 2, 10);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `Product_Code` int(10) NOT NULL,
  `Product_Name` varchar(120) NOT NULL,
  `Stocks` int(120) NOT NULL,
  `Released` int(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`Product_Code`, `Product_Name`, `Stocks`, `Released`) VALUES
(0, '0', 247, 0),
(121210, 'Biogesic', 40, 0);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
  `Company_Name` varchar(120) NOT NULL,
  `Owner` varchar(120) NOT NULL,
  `Address` varchar(120) NOT NULL,
  `Tin` varchar(20) NOT NULL,
  `Product_Code` int(20) NOT NULL,
  `Product_Name` varchar(120) NOT NULL,
  `Stocks_Add` int(120) NOT NULL,
  `Total_Amount` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tonsillitis`
--

CREATE TABLE IF NOT EXISTS `tonsillitis` (
  `Symptoms` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tonsillitis`
--

INSERT INTO `tonsillitis` (`Symptoms`) VALUES
('Sore throat '),
('Cough'),
('Headache');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
